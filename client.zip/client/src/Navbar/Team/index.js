import React from "react";

function Team() {
    return(
    <h1>Team Bro</h1>
    );
}

export default Team;