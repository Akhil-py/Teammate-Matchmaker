import React from "react";

function Profile() {
    return(
    <h1>Profile Bro</h1>
    );
}

export default Profile;